﻿import math
from mathutils import Vector
if "bpy" in locals():
    import importlib
    for m in (
        _Util,
        _UtilBlf,
        _MenuMode,
        _MenuModeHistory,
        _MenuUtility,
        _MenuObject,
        _MenuEditMesh,
        _MenuWeightPaint,
        _MenuTexturePaint,
        _MenuSculpt,
        _MenuSculptCurve,
        _MenuPose,
        _MenuUVEditor,
        _MenuImageEditor,
        _PanelSelectionHistory,
        _SwitchObjectData,
        g,
    ):
        importlib.reload(m)
else:
    import bpy
    from . import (
        _Util,
        _UtilBlf,
        _MenuMode,
        _MenuModeHistory,
        _MenuUtility,
        _MenuObject,
        _MenuEditMesh,
        _MenuWeightPaint,
        _MenuTexturePaint,
        _MenuSculpt,
        _MenuSculptCurve,
        _MenuPose,
        _MenuUVEditor,
        _MenuImageEditor,
        _PanelSelectionHistory,
        _SwitchObjectData,
        g,
    )
# --------------------------------------------------------------------------------
# ルートメニュー
# --------------------------------------------------------------------------------


class VIEW3D_MT_my_pie_menu(bpy.types.Menu):
    # bl_idname = "VIEW3D_PT_my_pie_menu"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_label = f"MyBestPieMenuEver v{g.ver[0]}.{g.ver[1]}.{g.ver[2]}"

    def draw(self, context):
        # 西、東、南、北、北西、北東、南西、南東
        pie = self.layout.menu_pie()
        # 西　最後に選択したモード
        _MenuModeHistory.draw_pie_menu(pie, context)
        # 東
        _SwitchObjectData.draw_pie_menu(pie, context)
        # 南
        row = pie.row()
        _MenuMode.draw_pie_menu(row, context)
        _MenuUtility.draw_pie_menu(row, context)
        # 北
        draw_primary(pie, context)


class MPM_OT_OpenPieMenuModal(bpy.types.Operator):
    bl_idname = "mpm.open_pie_menu"
    bl_label = "My Best Pie Menu Ever"
    imp = Vector((0, 0))

    def invoke(self, context, event):
        g.is_force_cancelled_piemenu_modal = False
        g.on_closed.clear()
        self.mp = Vector((event.mouse_x, event.mouse_y))
        safe_margin_min = (500, 450)
        safe_margin_max_y = 250
        # 左下が0,0
        self.__class__.imp = Vector((event.mouse_x, event.mouse_y))
        self.__class__.imp.x = max(self.mp.x, safe_margin_min[0])
        self.__class__.imp.y = _Util.clamp(self.mp.y, safe_margin_min[1], context.window.height - safe_margin_max_y)
        context.scene.mpm_prop.init()
        context.window_manager.modal_handler_add(self)
        self.draw_modal = self.DrawModal()
        bpy.ops.wm.call_menu_pie(name="VIEW3D_MT_my_pie_menu")
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        context.area.tag_redraw()
        self.mp = Vector((event.mouse_x, event.mouse_y))
        # print(event.type, event.is_consecutive, event.is_repeat)
        if event.type in {"RIGHTMOUSE", "ESC"} or g.is_force_cancelled_piemenu_modal:
            self.cancel(context)
            return {"CANCELLED"}

        elif event.type in {"LEFTMOUSE", "MOUSEMOVE", "NONE"}:
            if getattr(context.area.spaces.active, "image", None):
                context.area.spaces.active.image.reload()
            if event.shift or g.is_request_reopen_piemenu:
                # print(event.type, event.value, event.is_consecutive, event.is_repeat)
                g.is_request_reopen_piemenu = False
                context.window.cursor_warp(int(self.__class__.imp.x), int(self.__class__.imp.y))
                bpy.ops.wm.call_menu_pie(name="VIEW3D_MT_my_pie_menu")
                context.window.cursor_warp(event.mouse_x, event.mouse_y)
                return {"RUNNING_MODAL"}
            self.cancel(context)
            for i in g.on_closed.values():
                i()
            return {"FINISHED"}
        else:
            pass
            # 環境によって正しくない、ウィンドウ幅を取らないとだめなのかも。でもこの機能必要なさそうなのでコメント。
            # d = math.dist(self._init_mouse_pos, Vector((event.mouse_x, event.mouse_y)))
            # if 900 < d:
            #     context.window.screen = context.window.screen
            #     self.release(context)
            #     return {"CANCELLED"}
            # context.area.header_text_set("Offset %.4f %.4f %.4f" % tuple(self.offset))
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        # print("finish")
        context.area.tag_redraw()
        if self.draw_modal:
            self.draw_modal.cancel()
            self.draw_modal = None

    class DrawModal(_Util.MPM_ModalMonitor):
        def __init__(self):
            super().__init__()
            self.handler2d = bpy.types.SpaceView3D.draw_handler_add(self.draw2d, (), "WINDOW", "POST_PIXEL")

        def draw2d(self):
            if g.is_force_cancelled_piemenu_modal:
                self.cancel()
                return
            parent = MPM_OT_OpenPieMenuModal
            x = _Util.clamp(parent.imp.x - bpy.context.area.x, 0, bpy.context.area.width)
            y = _Util.clamp(parent.imp.y - bpy.context.area.y - 44, 0, bpy.context.area.height)
            _UtilBlf.draw_label("Holding Shift while clicking keeps this PIE open for sequential button presses!",
                                x, y, "center")

        def cancel(self):
            super().cancel()
            if self.handler2d:
                bpy.types.SpaceView3D.draw_handler_remove(self.handler2d, "WINDOW")
            self.handler2d = None


# class MPM_OT_OpenPieMenuModalMonitor(bpy.types.Operator):
#     bl_idname = "mpm.open_pie_menu_monitor"
#     bl_label = ""
#     _is_pie_menu_open = True  # パイメニューが開いているかのフラグ

#     def invoke(self, context, event):
#         self._is_pie_menu_open = True
#         context.window_manager.modal_handler_add(self)
#         bpy.app.timers.register(self.check_pie_menu_status, first_interval=0.1)
#         return {"RUNNING_MODAL"}

#     def modal(self, context, event):
#         if not self._is_pie_menu_open:
#             print("監視終了")
#             return {"CANCELLED"}
#         if event.type in {"LEFTMOUSE", "NONE"}:
#             print(event.type, event.is_consecutive, event.is_repeat)
#         return {"PASS_THROUGH"}

#     def check_pie_menu_status(self):
#         is_pie_open = any(op.bl_idname == "MPM_OT_open_pie_menu" for op in bpy.context.window.modal_operators)
#         if not is_pie_open:
#             self._is_pie_menu_open = False
#             return None
#         return 0.1

# --------------------------------------------------------------------------------
# モード中プライマリ処理
# --------------------------------------------------------------------------------


def draw_primary(pie, context):
    if context.space_data.type == "VIEW_3D":
        current_mode = context.mode
        if current_mode == "OBJECT":
            _MenuObject.draw(pie, context)
        elif current_mode == 'EDIT_MESH':
            _MenuEditMesh.draw(pie, context)
        elif current_mode == 'POSE':
            _MenuPose.draw(pie, context)
        elif current_mode == 'SCULPT':
            _MenuSculpt.draw(pie, context)
        elif current_mode == 'SCULPT_CURVES':
            draw_placeholder(pie, context, 'No Impl')
        elif current_mode == 'PAINT_TEXTURE':
            _MenuTexturePaint.draw(pie, context)
        elif current_mode == 'PAINT_VERTEX':
            draw_placeholder(pie, context, 'No Impl')
        elif current_mode == 'PAINT_WEIGHT':
            _MenuWeightPaint.draw(pie, context)
        elif current_mode == 'PARTICLE_EDIT':
            draw_placeholder(pie, context, 'No Impl')
        elif current_mode == 'EDIT_ARMATURE':
            draw_placeholder(pie, context, 'No Impl')
        elif current_mode == 'GPENCIL_DRAW':
            draw_placeholder(pie, context, 'No Impl')
        elif current_mode == 'GPENCIL_EDIT':
            draw_placeholder(pie, context, 'No Impl')
        elif current_mode == 'GPENCIL_SCULPT':
            draw_placeholder(pie, context, 'No Impl')
        elif current_mode == 'GPENCIL_WEIGHT_PAINT':
            draw_placeholder(pie, context, 'No Impl')
    elif context.space_data.type == "IMAGE_EDITOR":
        if context.space_data.mode == "UV":
            _MenuUVEditor.draw(pie, context)
        else:
            _MenuImageEditor.draw(pie, context)


def draw_placeholder(pie, context, text):
    box = pie.split().box()
    box.label(text=text)

# --------------------------------------------------------------------------------
# プロパティ
# context.scene.mpm_prop.IsAutoEnableWireframeOnSculptMode
# c.prop(context.scene.mpm_prop, "UVMapPopoverEnum")
# c.prop_with_popover(context.scene.mpm_prop, "ColorPalettePopoverEnum", text="", panel="MPM_PT_BrushColorPalettePanel",)
# --------------------------------------------------------------------------------


class MPM_Prop(bpy.types.PropertyGroup):
    def init(self):
        self.ColorPalettePopoverEnum = "ColorPalette"
        if bpy.context.tool_settings.image_paint.palette is not None:
            self.ColorPalettePopoverEnum = bpy.context.tool_settings.image_paint.palette.name

    # ビューポートカメラ位置保存スタック
    ViewportCameraTransforms: bpy.props.CollectionProperty(type=_MenuUtility.MPM_Prop_ViewportCameraTransform)

    # スカルプトモードのワイヤーフレーム
    IsAutoEnableWireframeOnSculptMode: bpy.props.BoolProperty() = False

    # テクスチャペイントのカラーパレット
    def on_update_color_palette_popover_enum(self, context):
        items = [("ColorPalette", "ColorPalette", "")]
        for i in bpy.data.palettes:
            items.append((i.name, i.name, ""))
        return items
    ColorPalettePopoverEnum: bpy.props.EnumProperty(
        name="ColorPalette Enum",
        description="Select an option",
        items=on_update_color_palette_popover_enum
    )

    # UVMap選択用
    def on_items_UVMapEnum(self, context):
        items = []
        obj = context.active_object
        if obj and obj.type == "MESH":
            uv_layers = context.active_object.data.uv_layers
            if uv_layers:
                for i in uv_layers:
                    items.append((i.name, i.name, ""))
        return items

    def on_set_UVMapEnum(self, value):
        uv_layers = bpy.context.active_object.data.uv_layers
        uv_layers.active = uv_layers[value]
        uv_layers.active.active_render = True

    def on_get_UVMapEnum(self):
        obj = bpy.context.active_object
        if not obj or obj.type != "MESH":
            return 0
        return obj.data.uv_layers.active_index
    UVMapPopoverEnum: bpy.props.EnumProperty(
        name="UVMap",
        description="Select UV Map want to be active",
        items=on_items_UVMapEnum,
        get=on_get_UVMapEnum,
        set=on_set_UVMapEnum
    )

    # Vertex Group選択用
    def on_items_VertexGroupEnum(self, context):
        items = []
        obj = context.active_object
        if obj and obj.type == "MESH":
            vgs = obj.vertex_groups
            if vgs:
                for i in vgs:
                    items.append((i.name, i.name, ""))
        return items

    def on_set_VertexGroupEnum(self, value):
        vgs = bpy.context.active_object.vertex_groups
        vgs.active_index = value

    def on_get_VertexGroupEnum(self):
        obj = bpy.context.active_object
        if not obj or obj.type != "MESH":
            return 0
        return obj.vertex_groups.active_index
    VertexGroupPopoverEnum: bpy.props.EnumProperty(
        name="VertexGroup",
        description="Select Vertex Group want to be active",
        items=on_items_VertexGroupEnum,
        get=on_get_VertexGroupEnum,
        set=on_set_VertexGroupEnum
    )

    # Shapekey選択用
    def on_items_ShapeKeyEnum(self, context):
        items = []
        obj = context.active_object
        if obj and obj.type == "MESH":
            group_map = {}
            group_id_counter = 0
            if obj.data and obj.data.shape_keys:
                for sk in obj.data.shape_keys.key_blocks:
                    prefix = sk.name[:3]
                    if prefix not in group_map:
                        group_map[prefix] = group_id_counter
                        group_id_counter += 1
                        # items.append(("", prefix, ""))
                    group_id = group_map[prefix]
                    items.append((sk.name, sk.name, ""))
        return items

    def on_set_ShapeKeyEnum(self, value):
        obj = bpy.context.active_object
        obj.active_shape_key_index = value

    def on_get_ShapeKeyEnum(self):
        obj = bpy.context.active_object
        if not obj or obj.type != "MESH":
            return 0
        return obj.active_shape_key_index
    ShapeKeyPopoverEnum: bpy.props.EnumProperty(
        name="Shapekey",
        description="Select Shape Key want to be active",
        items=on_items_ShapeKeyEnum,
        get=on_get_ShapeKeyEnum,
        set=on_set_ShapeKeyEnum
    )

    # アニメーション速度用
    def on_set_AnimationSpeed(self, v):
        bpy.context.scene.render.frame_map_old = 100
        bpy.context.scene.render.frame_map_new = math.ceil(100 / v)

    def on_get_AnimationSpeed(self):
        return bpy.context.scene.render.frame_map_old / bpy.context.scene.render.frame_map_new

    AnimationSpeed: bpy.props.FloatProperty(
        name="Animation Speed",
        default=1.0,
        min=0.1,
        max=10.0,
        step=0.1,
        set=on_set_AnimationSpeed,
        get=on_get_AnimationSpeed
    )

    # ARPエクスポートパネル選択リスト用
    ARPExportTargetList: bpy.props.CollectionProperty(type=_MenuUtility.MPM_OT_Utility_ARPExport.Item)


# --------------------------------------------------------------------------------
classes = (
    VIEW3D_MT_my_pie_menu,
    MPM_OT_OpenPieMenuModal,
    MPM_Prop,
)
modules = [
    _MenuMode,
    _MenuModeHistory,
    _MenuUtility,
    _MenuObject,
    _MenuEditMesh,
    _MenuWeightPaint,
    _MenuTexturePaint,
    _MenuPose,
    _MenuSculpt,
    _MenuSculptCurve,
    _MenuUVEditor,
    _MenuImageEditor,
    _SwitchObjectData,
    _PanelSelectionHistory,
    g,
]


def register():
    for m in modules:
        m.register()
    _Util.register_classes(classes)
    bpy.types.Scene.mpm_prop = bpy.props.PointerProperty(type=MPM_Prop)


def unregister():
    for m in modules:
        m.unregister()
    _Util.unregister_classes(classes)
    del bpy.types.Scene.mpm_prop
