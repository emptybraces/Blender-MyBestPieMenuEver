is_force_cancelled_piemenu_modal = False # メニューモーダルの強制キャンセル。
is_request_reopen_piemenu = False # パイメニュー再起動リクエスト
